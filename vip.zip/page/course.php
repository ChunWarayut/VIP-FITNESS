<link href="css/course.css" rel="stylesheet">
        <!-- PAGE CONTAINER-->
            <!-- MAIN CONTENT-->
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                <div class="card">
                  <div class="card-header">
                    <strong class="card-title">ตารางการเทรน</strong>
                  </div>
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <th>date</th>
                                                <th></th>
                                                <th>การเทรน</th>
                                                <th></th>
                                                <th></th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>วันที่ 1</td>
                                                <td>อก</td>
                                                <td>แขนหลัง</td>
                                                <td>ท้อง</td>
                                            </tr>
                                            <tr>
                                                <td>วันที่ 2</td>
                                                <td>ไหล่</td>
                                                <td>แขนหน้า</td>                                                
                                            </tr>
                                            <tr>
                                                <td>วันที่ 3</td>
                                                <td>หลัง</td>
                                                <td>ขา</td>
                                                <td>ท้อง</td>
                                                <td>วิ่งเบาๆ</td>
                                            </tr>
                                            <tr>
                                                <td>วันที่ 4</td>
                                                <td>-</td>
                                                <td>พัก</td>
                                                <td>-</td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>วันที่ 5</td>
                                                <td>อก</td>
                                                <td>แขนหลัง</td>
                                                <td>ท้อง</td>
                                                <td>วิ่งเบาๆ</td>
                                            </tr>
                                            <tr>
                                                <td>วันที่ 6</td>
                                                <td>ไหล่</td>
                                                <td>แขนหน้า</td>                                               
                                            </tr>
                                            <tr>
                                                <td>วันที่ 7</td>
                                                <td>หลัง</td>
                                                <td>ขา</td>
                                                <td>ท้อง</td>
                                                <td>วิ่งเบาๆ</td>
                                            </tr>
                                            <tr>
                                                <td>วันที่ 8</td>
                                                <td>-</td>
                                                <td>พัก</td>
                                                <td>-</td>
                                                <td>-</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <!-- END DATA TABLE-->
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="copyright">
                                    <p>Copyright © 2018 Colorlib. All rights reserved. Template by <a href="https://colorlib.com">Colorlib</a>.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>